<!DOCTYPE html >
<html>
    <head>
        <title> The HTML formated text of the tags </title>
        <meta name = "description" content = "Run basic tags"/>
    </head>
    <body>
        <p> Hello Beginer!</p>
        <div>
            <h1> Welcomer to The HTML formated text of the tags </h1>
            <h2> The HTML formated text of the tags is dedicated to providing you with:</h2>
            <p> <b> This text is in Bold.</b></p>
            <p> <i> This text is in Italic. </i></p>
            <h2> I want to put  a <mark> mark</mark> on this document</h2>
            <p><u> This text is underlined.</u></p>
            <p> <strike>The following text is strikethrough</strike>.</p>
            <p>Ax <sup>3</sup>+BX<sub>2</sup>+CX+B=0</p>
                <p>H <sub>2</sub>O</p>
                <p> <del>Delete a piece of text.</del></p>
                <p> Hello<big> The text has small font.</big></p>
                <p> Hello <small> The text has small font.</small></p>
                <p> <span style="color: red"> Red word</span></p>
                <p> <span style="color: white; background-color: red;"> The text has a red background and white color</span></p>
                <p> <span style="font-size: 32px"> Text size is 32px</span></p>
            </div>
    </body>
</html>
   