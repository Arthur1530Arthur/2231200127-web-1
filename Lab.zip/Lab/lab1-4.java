<!DOCTYPE html >
    <html>
    <head>
        <meta charset="utf-8">
        <META name = "viewport" content = "width = device -width, initial-scale =1.0">
            <title>Image and Link</title>
    </head>
    <body background="img\Background.jpg">
        <h1> Images and Links in HTML</h1>
        <div>
            <h2>HTML links</h2>
            <p> Hyperlinks Syntax: The HTML <b> < a > </b> tag defines a Hyperlinks. It has the following syntax: </p>
            <p> <span style="color: blue;"> < a href="url">link text< /a></span></p>
            <p><b><i> Example: </i></b> <a href="https:www.w3school.com/"> Visit w3school.com</a></p>
        </div>
        <div>
            <h2>Images in HTML</h2>
            <ol type ="1">
                <li ><b> Set background image for the page </b></li>
                <p> <span style="color: white;"> < body background="file name"> < /body></span></p>
                <li><b> Insert images into Folder</b></li>
                <p> <span style="color: yellow;"> < img src ="link to folder" title= "Note"</span></p>
                <img src="img\1.jpg" alt = "flower" title="flower-poem-10%" style="height: 10%;width: 10%;">
                <li> <p> Insert images into Web pages </p></li>
                <p> <span style="color: red;"> < img src ="Copy image address" title= "Note"</span></p>
                <img src="https://cdn.haitrieu.com/wp-content/uploads/2021/12/Logo-DH-Quoc-Te-Mien-Dong-EIUVi.png" alt = "LINK TO eiu logo"
                 title="flower-poem-15%" style="height: 15%;width: 15%;">

            </ol>
        </div>
    </body>
    </html>
    