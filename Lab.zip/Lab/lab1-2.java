<!DOCTYPE html >
    <html>
    <head>
    <meta charset=<"utf-8">
    <title> Learn HTML </title>
    <meta name = "description" content = "Học HTML"/>
    </head>

    <body>
        <h1> Lesson 1: Using basic tags.</h1>
        <h2> 1.1 Learn basic function tags.</h2>
        <p> HTML tags contain 3 main components: opening tag-content-closing tag, but 
            there are several tags <u><i>that both open and close</i></u><p>
        <p><i><b> Syntax: Tag name [Attribute] - Affected element - Tag name</b></i></p> 
        <p><i><u> Note:</u><i> HTML tags are always lowercase, nesting tags is allowed, and tags are
            written on the same line or multiple lines.</p>
        <h2>1.2. Design a website as required </h2>
        <p><b><u>Request </u></b></p>
        <p> Website design has the following content</p>
        <center> Chia sẻ kiến thức  </centre>
        <center> Chào mừng các bạn đến với ngôn ngữ HTML</centre>
    </body>
</html>
    