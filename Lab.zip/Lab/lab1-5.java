<!DOCTYPE html >
<html>
<head>
<title> ABC Bookstore</title>
</head>
<body>
        <h2><center> INTRODUCING ABC BOOK TRADING AND SERVICES JOINT STOCK COMPANY</center></h2>
        <p><b> ABC Book Trading and Services Joint Stock Company</b>is one of the first few e-commerce
            companies in Vietnam to start with a website <a href="e www.abc.com "> </a>since December 2005</p>
        <img src="img/logoABC.png" alt="logoABC" style="width: 100%; height: 300px;">
        <p><b> <span style="color: red;">PRINCIPLES OF OPERATION </span></b></p>
        <ul>
            <li>Absolutely respect copyright and publishing laws</li>
            <li>Committed to creating quality, valuable books that always keep up with current trends</li>
            <li>Be reader-centered</li>
            <li>Increase benefits for partners</li>
            <li>Awaken and promote each individual's creative abilities</li>
        </ul>
        <p><b> <span style="color: blue;">BUSINESS ORIENTATION</span></b></p>
    <ol>
        <li>Buy copyright, translate and publish publications from foreign languages into
            Vietnamese and vice versa with bookcases:</li>
            <ul type="disc" >
                <li><i>V-Biz: </i> The books provide highly applicable ways of thinking, experience, and skills for leader,
                        people operating in the business filed, office workers, etc. </li>
                <li><i>V-Buddism: </i>Thaihabooks'applied Buddhism bookshelf always receives the attention and trust of Buddism and readers.
                        The book bring profound Buddhist philosophies but are still relevant to everyday life, helping each 
                        person live happier and more meaningful life.</li>
                <li><i>V-Parents: </i>The books help parents raise their children better and understand them better based on advice
                        from leading experts in Vietnam and the world</li>
                <li><i>V-Teen: </i>These books help solve problems, awaken potential, and provide career orientation for teenagers.</li>
                <li><i>V-Smile: </i>Including books on the topics of culture, literature, education, history, travel, enriching your
                        spiritual life, adding knowledge and expertise in many areas of your life read.</li>
                    </ul>
        <li>Providing services related to copyright and publishing.</li>
        <li>Providing books, newspapers, magazines, and other publications to readers.</li>
        <li>Printing and printing-related services.</li>
        <li>Organize events related to books, journalism and publishing.</li>
</ol>
        <h4><i> In case you have any needs or question about the book, do not hesitate to send 
            us an email at: <a href="mailto:support@abc.com" support@abc.com></a>or send and leave a message on
            the page <a href="Contact.html">Contact</a> </i></h4>
</body>