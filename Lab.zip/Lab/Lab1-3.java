<!DOCTYPE html >
    <html>
    <head>
        <title> List in HTML</title>
        <meta charset = "utf-8"/>
        <meta name = "description" content = "Run list page in HTML"/>
    </head>
    <body>
        <p> Hello Beginer!</p>
        <div>
            <h1> Welcome to List in HTML </h1>
                <h2>1. List in HTML </h2>
                <d1>
                    <dt> List in HTML </dt>
                    <dd> - Used to display lists of information </dd>
                </d1>
                <p> There are three differents type of HTML lists</p>
                <h3> Below is Ordered lists of numbered list (ol)</h3>
                <ol> 
                    <li> Ordered list or numbered list (ol)</li>
                    <li> Unodered list (ul)</li>
                    <li> Defintion list (dl)</li>
                </ol>
                <h3> Unnumbered List </h3>
                <ul type = "circle">
                    <li> HTML & FrontEnd Language</li>
                    <li> DreamWeaver MX </li>
                    <li type = "square"> Domain Exploitation and Administration, Hosting </li>
                    <li type = "square"> JavaScript scripting Language; </li>
                    <li type = "square"> Programing Language ASAP &amp amp; SQLSever </li>
                </ul>
                <h2>2. Nested Lists</h2>
                <ol type ="I">
                    <li> <b> WEBSITE DESIGN </b>
                        <ol type ="1">
                            <li> HTML Language &amp amp; ForntPage </li>
                            <li> JavaScript scripting language</li>
                            <li> Media Flash MX</li>
                            <li> Photoshop interface design</li>
                            <li> DreamWeaver Mx Website Design</li>
                        </ol>
                    </li>
                    <li> <b> WEBSITE PROGRAMING </b>
                            <ol type ="1">
                                <li> Analysis &ampamp; Database design</li>
                                <li> Database Programming ASP.NET &amp amp; SQL Server</li>
                                <li> Website Administration</li>
                                <li> Graduation topic </li>
                            </ol>
                </ol>
            </div>
    </body>