<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Doge Social Netowrk</title>
    </head>
    <body span style="background-color: powderblue;">
        <h1>Doge Social Network</h1>
        <ul>
            <li><a href="home.html">Html</a></li>
            <li><a href="profile.html">Profile</a></li>
            <li><a href="friends.html">Friends</a></li>
        </ul>
        <div style="background-color: green;"><h2>Welcome to Doge Social Network</h2></div>
       <center> <img src="img/Doge.jpg" alt="The Dog picture" style="height: 30%; width: 30%;"></center>
        <ul>
            <span style="color: brown;"></span>
            <li><b>Name: </b> Doge</li>
            <li><b>Birthday: </b> Top secret</li>
            <li><b>occupation: </b> Celebrity</li>
            <li><b>Area of occupation: </b> Web</li>
        </ul>
    </body>

</html>