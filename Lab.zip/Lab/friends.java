<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Doge Social Netowrk</title>
    </head>
    <body span style="background-color: powderblue;">
        <h1>Doge Social Network</h1>
        <ul>
            <li><a href="home.html">Html</a></li>
            <li><a href="profile.html">Profile</a></li>
            <li><a href="friends.html">Friends</a></li>
        </ul>
        <div style="background-color: green;"><h2>Welcome to Doge Social Network</h2></div>
        <p>Here you can find friends or stalk stranger</p>
        <p>The Doge Social Network does not take any responsibility for the information found</p>
    </body>
        <dl>
            <dt><i>Such Friend</i></dt>
            <dd> best friends</dd>
            <dt><i>Many Friends</i></dt>
            <dd>unknown</dd>
            <dt>Wow</dt>
            <dd>yeah, right</dd>
        </dl>
</html>