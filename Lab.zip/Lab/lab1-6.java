<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"
        <title>Nhan Ai Fresh Flower Company</title>
    </head>
    <style>
        #img{float: left; width: 700px; height: 400px;}
        #text{float:right}
        #pink{background-color: hotpink; font-weight: bold; color: white;}
    </style>
    <body>
        <h1 style="color: hotpink; text-align: center; font-size: 40xp;">Nhan Ai Fresh Flower Company </h1>
        <div id="img">
            <center><img src="\img/" style="height: 500px;width: 500px;"</center>
        </div>
        <div id="text">
            <span id="pink" style="font-size: 30px;">1. Introduce</span>
            <ul style="font-size: 20px;">
                <li>Establish: <b>25/05/2007</b></li>
                <li>Specializing in providing fresh flowers</li>
                <li> There are over 20 flowers shops in Ho Chi Minh City</li>
                <li> Receive flower baskets according to customer requests</li>
                </ul>
                <span>----------------------------------------------------</span>
                <br/>       
        </div>
        <div>
            <span id="pink" style="font-size: 30px;">2. Liên hệ</span>
            <ul style="font-size: 20px;">
                <li><b>Điện thoại:</b>84-08-8351056</li>
                <li><b> Địa chỉ: </b>227 Nguyễn Văn Cừ, Quận 5, TP HCM</li>
            </ul>
        </div>
        <div style="background-color: pink; margin-left: 20%;"> @copyright: <a href="https://www.theflowerweb.com.au">theflower.com.au</a></div>
    </body>
</html>